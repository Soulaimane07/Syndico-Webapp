

<?php $__env->startSection('title', __('lang.footer') ); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
  
                    <div class="title">
                      <h4 class="card-title"> <?php echo e(__('lang.footer')); ?> ( <?php echo e($footer->count()); ?> )</h4>
  
                      
                      <button type="button" class="create btn btn-primary" data-bs-toggle="modal" data-bs-target="#create"> 
                        <i class="icon-plus"></i> 
                        <?php echo e(__('lang.createitem')); ?>

                      </button>
                      
                    </div>
                    
                    <?php if($footer->count() > 0): ?> 
  
                    <div class="table-responsive">
                    
                        <table id="zero_config" class="table table-striped table-bordered display no-wrap"
                          style="width:100%">
                            <thead>
                                <tr>
                                  <th>#</th>
                                  <th><?php echo e(__('lang.title')); ?> </th>
                                  <th><?php echo e(__('lang.logo')); ?> </th>
                                  <th> <?php echo e(__('lang.link')); ?> </th>
                                  <th> <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.fr')); ?> </th>
                                  <th> <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.an')); ?> </th>
                                  <th> <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.ar')); ?> </th>
                                  <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td><?php echo e($item['id']); ?></td>
                                  <td>
                                    <?php if(strlen($item['title']) > 10): ?>
                                        <?php echo e(Str::limit($item['title'], 10)); ?>

                                    <?php else: ?>
                                        <?php echo e($item['title']); ?>

                                    <?php endif; ?>  
                                  </td>
                                  <td>
                                
                                    <?php if(strlen($item['logo']) > 10): ?>
                                        <?php echo e(Str::limit($item['logo'], 10)); ?>

                                    <?php else: ?>
                                        <?php echo e($item['logo']); ?>

                                    <?php endif; ?>  
                                    
                                    </td>
                                  <td>
                                    <?php if(strlen($item['link']) > 20): ?>
                                        <?php echo e(Str::limit($item['link'], 20)); ?>

                                    <?php else: ?>
                                        <?php echo e($item['link']); ?>

                                    <?php endif; ?>  </td>
                                    <td>
                                        <?php if(strlen($item['para_Fr']) > 20): ?>
                                            <?php echo e(Str::limit($item['para_Fr'], 20)); ?>

                                        <?php else: ?>
                                            <?php echo e($item['para_Fr']); ?>

                                        <?php endif; ?>  </td>
                                    <td>
                                        <?php if(strlen($item['para_An']) > 20): ?>
                                            <?php echo e(Str::limit($item['para_An'], 20)); ?>

                                        <?php else: ?>
                                            <?php echo e($item['para_An']); ?>

                                        <?php endif; ?>  </td>
                                    <td>
                                        <?php if(strlen($item['para_Ar']) > 20): ?>
                                            <?php echo e(Str::limit($item['para_Ar'], 20)); ?>

                                        <?php else: ?>
                                            <?php echo e($item['para_Ar']); ?>

                                        <?php endif; ?>  
                                    </td>
                                    <td>
                                        <a href=<?php echo e('/edit-item/'.$item['id']); ?>> <button class="edit"> <i class=" icon-pencil"></i> </button> </a>
            
                                        <form action="<?php echo e(url('/delete-footer/'.$item['id'])); ?>" method="post">
                                            <?php echo e(method_field('DELETE')); ?>

                                            <?php echo e(csrf_field()); ?>

                                            <button id="delete" class='delete'><i class=" icon-trash" ></i></button> 
                                        </form> 
                                    </td>
                              </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
  
                    <?php else: ?>
                    
                    <div class='nodata'>
                      <div class='video'>
                        <video autoplay muted loop src="assets/videos/nodata.mp4"></video>
                      </div>
                        <h2> <?php echo e(__('lang.nodata')); ?> </h2> 
                    </div>
                    
                    <?php endif; ?>
  
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="create" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel"> <?php echo e(__('lang.createitem')); ?></h5>
            </div>
            <div class="modal-body">
                <form method="POST" action="create-footer">
                    <?php echo csrf_field(); ?>
    
                    <div class="mb-3">
                      <label for="name" class="form-label"> <?php echo e(__('lang.title')); ?></label>
                      <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control" id="name" >
                      <span class="text-danger"> <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                    </div>
                    <div class="mb-3">
                      <label for="name" class="form-label"> <?php echo e(__('lang.logo')); ?></label>
                      <input type="text" name="logo" value="<?php echo e(old('logo')); ?>" class="form-control" id="name" >
                      <span class="text-danger"> <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                    </div>
                    <div class="mb-3">
                      <label for="name" class="form-label"> <?php echo e(__('lang.link')); ?></label>
                      <input type="text" name="link" value="<?php echo e(old('link')); ?>" class="form-control" id="name" >
                      <span class="text-danger"> <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                    </div>
                    
                    <h4 class="title"> <?php echo e(__('lang.para')); ?> </h4>
                    <div class="mb-3">
                        <label for="name" class="form-label"> <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.fr')); ?></label>
                        <input type="text" name="para_Fr" value="<?php echo e(old('para_Fr')); ?>" class="form-control" id="name" >
                        <span class="text-danger"> <?php $__errorArgs = ['para_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                      </div>
                      <div class="mb-3">
                        <label for="name" class="form-label"> <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.an')); ?></label>
                        <input type="text" name="para_An" value="<?php echo e(old('para_An')); ?>" class="form-control" id="name" >
                        <span class="text-danger"> <?php $__errorArgs = ['para_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                      </div>
                      <div class="mb-3">
                        <label for="name" class="form-label"> <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.ar')); ?></label>
                        <input type="text" name="para_Ar" value="<?php echo e(old('para_Ar')); ?>" class="form-control" id="name" >
                        <span class="text-danger"> <?php $__errorArgs = ['para_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                      </div>
                    
                    
                    <div class="modal-footer d-flex justify-content-between ">
                        <button type="submit" class="btn btn-primary"> <?php echo e(__('lang.create')); ?> </button>
                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal"> <?php echo e(__('lang.cancel')); ?> </button>
                    </div>
                  </form>
            </div>
          </div>
        </div>
    </div>

</div>          

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syndico1\resources\views/topics/footer.blade.php ENDPATH**/ ?>