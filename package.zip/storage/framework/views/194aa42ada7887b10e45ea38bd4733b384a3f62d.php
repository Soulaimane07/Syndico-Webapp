

<?php $__env->startSection('title', __('lang.demandes') ); ?>

<?php 
    $x = 0 ;
    $y = 0 ;
    foreach($demandes as $demande){
        $x = $demande['n_imm'] + $x;
        $y = $demande['n_app'] + $y; 
    }
?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <div class="title">
                            <h4 class="card-title"><?php echo e(__('lang.demandes')); ?> ( <?php echo e($demandes->count()); ?> )</h4>
                            <button type="button" class="create btn btn-primary" data-bs-toggle="modal" data-bs-target="#create"> 
                                <i class="icon-plus"></i> 
                                <?php echo e(__('lang.createdemande')); ?>

                            </button>
                        </div>

                        <div class="row">
                            <!-- Column -->
                            <div class="col-md-6 col-xlg-3">
                                <div class="card card-hover">
                                    <div class="p-2 bg-primary text-center rounded">
                                        <h1 class="font-light text-white">
                                            <?php echo e($x); ?>

                                        </h1>
                                        <h6 class="text-white"> <?php echo e(__('lang.totalimm')); ?> </h6>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 col-xlg-3">
                                <div class="card card-hover">
                                    <div class="p-2 bg-danger text-center rounded">
                                        <h1 class="font-light text-white">
                                            <?php echo e($y); ?>

                                        </h1>
                                        <h6 class="text-white"> <?php echo e(__('lang.totalapp')); ?> </h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <?php if($demandes->count() > 0): ?>
                        <div class="table-responsive">
                            <table id="zero_config" class="table table-striped table-bordered display no-wrap"
                                style="width:100%">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th> <?php echo e(__('lang.name')); ?> </th>
                                        <th><?php echo e(__('lang.email')); ?></th>
                                        <th><?php echo e(__('lang.phone')); ?></th>
                                        <th><?php echo e(__('lang.city')); ?></th>
                                        <th><?php echo e(__('lang.imm')); ?></th>
                                        <th><?php echo e(__('lang.app')); ?></th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $demandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $demande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($demande['id']); ?></td>
                                        <td><?php echo e($demande['full_name']); ?></td>
                                        <td><?php echo e($demande['email']); ?></td>
                                        <td><?php echo e($demande['phone']); ?></td>
                                        <td><?php echo e($demande['city']); ?></td>
                                        <td><?php echo e($demande['n_imm']); ?></td>
                                        <td><?php echo e($demande['n_app']); ?></td>
                                        <td>

                                          <?php if(Auth::user()->is_admin == 1 ): ?>

                                            <a href=<?php echo e('/edit-demande/'.$demande['id']); ?>> <button class="edit"> <i class=" icon-pencil"></i> </button> </a>
            
                                            <form action="<?php echo e(url('/delete-demande/'.$demande['id'])); ?>" method="post">
                                                <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button id="delete" class='delete'><i class=" icon-trash" ></i></button> 
                                            </form> 

                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <?php else: ?>
                        <div class='nodata'>
                            <div class='video'>
                            <video autoplay muted loop src="assets/videos/nodata.mp4"></video>
                            </div>
                            <h2> <?php echo e(__('lang.nodata')); ?> </h2> 
                        </div>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
        

        <div class="modal fade" id="create" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel"> <?php echo e(__('lang.createdemande')); ?> </h5>
                </div>
                <div class="modal-body">
                    <form method="POST" action="create-demandes">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label"><?php echo e(__('lang.name')); ?></label>
                            <input type="text" name="full_name" value="<?php echo e(old('full_name')); ?>" class="form-control" id="name" aria-describedby="emailHelp">
                            <span class="text-danger"> <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                        </div>
                        <div class="mb-3">
                          <label for="exampleInputEmail1" class="form-label"><?php echo e(__('lang.email')); ?></label>
                          <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                          <span class="text-danger"> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label"> <?php echo e(__('lang.phone')); ?></label>
                            <input type="number" name="phone" value="<?php echo e(old('phone')); ?>" class="form-control" id="phone" aria-describedby="emailHelp">
                            <span class="text-danger"> <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                        </div>
                          <div class="mb-3">
                            <label for="city" class="form-label"><?php echo e(__('lang.city')); ?></label>
                            <input type="text" name="city" value="<?php echo e(old('city')); ?>" class="form-control" id="city" aria-describedby="emailHelp">
                            <span class="text-danger"> <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                        </div>
                          <div class="mb-3">
                            <label for="imm" class="form-label"><?php echo e(__('lang.imm')); ?></label>
                            <input type="number" name="n_imm" value="<?php echo e(old('n_imm')); ?>" class="form-control" id="number" aria-describedby="emailHelp">
                            <span class="text-danger"> <?php $__errorArgs = ['n_imm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                        </div>
                          <div class="mb-3">
                            <label for="app" class="form-label"><?php echo e(__('lang.app')); ?></label>
                            <input type="number" name="n_app" value="<?php echo e(old('n_app')); ?>" class="form-control" id="app" aria-describedby="emailHelp">
                            <span class="text-danger"> <?php $__errorArgs = ['n_app'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                        </div>
                        
                        <div class="modal-footer d-flex justify-content-between ">
                            <button type="submit" class="btn btn-primary"><?php echo e(__('lang.create')); ?></button>
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('lang.cancel')); ?></button>
                        </div>
                      </form>
                </div>
              </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syndico1\resources\views/demandes.blade.php ENDPATH**/ ?>