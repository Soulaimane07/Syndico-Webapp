

<?php $__env->startSection('title', __('lang.aboutus') ); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
          
  <div class="row">
      <div class="col-12">
          <div class="card">
              <div class="card-body">

                  <div class="title">
                      <h4 class="card-title"> <?php echo e(__('lang.aboutus')); ?> </h4>

                      <?php if($aboutus->count()==0): ?>
                      <button type="button" class="create btn btn-primary" data-bs-toggle="modal" data-bs-target="#create"> 
                        <i class="icon-plus"></i> 
                        <?php echo e(__('lang.createitem')); ?>

                    </button>
                    <?php endif; ?>

                  </div>
                  
                  <?php if($aboutus->count() > 0): ?> 

                  <div>
                    <div class="text-white aboutus bg-primary rounded">
                      <div class="row p-2 px-4">
                        <div class="col">
                          Key
                        </div>
                        <div class="col">
                          Value
                        </div>
                      </div>
                    </div>
                    <?php $__currentLoopData = $aboutus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aboutus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <div class="row p-3 border-bottom">
                          <div class="col">
                            <?php echo e(__('lang.title')); ?> <?php echo e(__('lang.fr')); ?>

                          </div>
                          <div class="col">
                            <?php echo e($aboutus->title_Fr); ?>

                          </div>
                        </div>
                        <div class="row p-3 border-bottom">
                          <div class="col">
                            <?php echo e(__('lang.title')); ?> <?php echo e(__('lang.an')); ?>

                          </div>
                          <div class="col">
                            <?php echo e($aboutus->title_An); ?>

                          </div>
                        </div>
                        <div class="row p-3 border-bottom">
                          <div class="col">
                            <?php echo e(__('lang.title')); ?> <?php echo e(__('lang.ar')); ?>

                          </div>
                          <div class="col">
                            <?php echo e($aboutus->title_Ar); ?>

                          </div>
                        </div>
                        <div class="row p-3 border-bottom">
                          <div class="col">
                            <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.fr')); ?>

                          </div>
                          <div class="col">
                            <?php echo e($aboutus->para_Fr); ?>

                          </div>
                        </div>
                        <div class="row p-3 border-bottom">
                          <div class="col">
                            <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.an')); ?>

                          </div>
                          <div class="col">
                            <?php echo e($aboutus->para_An); ?>

                          </div>
                        </div>
                        <div class="row p-3 border-bottom">
                          <div class="col">
                            <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.ar')); ?>

                          </div>
                          <div class="col">
                            <?php echo e($aboutus->para_Ar); ?>

                          </div>
                        </div>
                        <div class="row p-3 border-bottom">
                          <div class="col">
                            <?php echo e(__('lang.image')); ?>

                          </div>
                          <div class="col">
                            <?php echo e($aboutus->image); ?>

                          </div>
                        </div>
                    </tbody>
                    <div class="text-white aboutus ">
                      <div class="row p-2">
                        <div class="col">
                          <a href=<?php echo e('/edit-aboutus/'.$aboutus['id']); ?>> <button class="edit"> <i class=" icon-pencil"></i> <?php echo e(__('lang.edit')); ?> </button> </a>
                        </div>
                        <div class="col">
                          <form action="<?php echo e(url('/delete-aboutus/'.$aboutus['id'])); ?>" method="post">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                            <button id="delete" class='delete'><i class=" icon-trash" ></i> <?php echo e(__('lang.delete')); ?> </button> 
                          </form> 
                        </div>
                      </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                  </div>

                  <?php else: ?>
                  
                  <div class='nodata'>
                    <div class='video'>
                      <video autoplay muted loop src="assets/videos/nodata.mp4"></video>
                    </div>
                      <h2> <?php echo e(__('lang.nodata')); ?> </h2> 
                  </div>
                  
                  <?php endif; ?>

              </div>
          </div>
      </div>
  </div>

  <div class="modal fade" id="create" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"> <?php echo e(__('lang.create')); ?> <?php echo e(__('lang.aboutus')); ?> </h5>
        </div>
        <div class="modal-body">
            <form method="POST" action="create-aboutus-item" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                  <label for="name" class="form-label"> <?php echo e(__('lang.title')); ?> <?php echo e(__('lang.fr')); ?></label>
                  <input type="text" name="title_Fr" value="<?php echo e(old('title_Fr')); ?>" class="form-control" id="name" >
                  <span class="text-danger"> <?php $__errorArgs = ['title_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                  <label for="name" class="form-label"> <?php echo e(__('lang.title')); ?> <?php echo e(__('lang.an')); ?></label>
                  <input type="text" name="title_An" value="<?php echo e(old('title_An')); ?>" class="form-control" id="name" >
                  <span class="text-danger"> <?php $__errorArgs = ['title_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                  <label for="name" class="form-label"> <?php echo e(__('lang.title')); ?> <?php echo e(__('lang.ar')); ?></label>
                  <input type="text" name="title_Ar" value="<?php echo e(old('title_Ar')); ?>" class="form-control" id="name" >
                  <span class="text-danger"> <?php $__errorArgs = ['title_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                  <label for="name" class="form-label"> <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.fr')); ?></label>
                  <input type="text" name="para_Fr" value="<?php echo e(old('para_Fr')); ?>" class="form-control" id="name" >
                  <span class="text-danger"> <?php $__errorArgs = ['para_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                  <label for="name" class="form-label"> <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.an')); ?></label>
                  <input type="text" name="para_An" value="<?php echo e(old('para_An')); ?>" class="form-control" id="name" >
                  <span class="text-danger"> <?php $__errorArgs = ['para_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                  <label for="name" class="form-label"> <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.ar')); ?></label>
                  <input type="text" name="para_Ar" value="<?php echo e(old('para_Ar')); ?>" class="form-control" id="name" >
                  <span class="text-danger"> <?php $__errorArgs = ['para_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="form-group mb-3">
                  <label for="" class="form-label"> Image </label>
                  <input type="file" value="<?php echo e(old('image')); ?>" name="image" class="form-control" >
                  <span class="text-danger"> <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
              </div>
                
                
                <div class="modal-footer d-flex justify-content-between ">
                    <button type="submit" class="btn btn-primary"> <?php echo e(__('lang.create')); ?> </button>
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal"> <?php echo e(__('lang.cancel')); ?> </button>
                </div>
              </form>
        </div>
      </div>
    </div>
  </div>

</div>          

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syndico1\resources\views/topics/aboutus.blade.php ENDPATH**/ ?>