

<?php $__env->startSection('title',__('lang.edit') .' '. __('lang.contact')); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <h2 class="page-title text-truncate text-dark font-weight-medium mb-1"> <?php echo e(__('lang.edit')); ?> <?php echo e(__('lang.contact')); ?> </h2>
        <form method="POST" action="<?php echo e(url('/edit-connect/'.$data['id'])); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <label for="" class="form-label">  <?php echo e(__('lang.image')); ?>  </label>
                <input type="file" value="<?php echo e($data['image']); ?>" name="image" class="form-control" >
                <span class="text-danger"> <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>

            <h4 class="title"> <?php echo e(__('lang.title')); ?> </h4>
            <div class="mb-3">
                <label for="title_Fr" class="form-label"><?php echo e(__('lang.title')); ?> <?php echo e(__('lang.fr')); ?></label>
                <input type="text" name="title_Fr" value="<?php echo e($data['title_Fr']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['title_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="title_An" class="form-label"><?php echo e(__('lang.title')); ?> <?php echo e(__('lang.an')); ?></label>
                <input type="text" name="title_An" value="<?php echo e($data['title_An']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['title_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="title_Ar" class="form-label"><?php echo e(__('lang.title')); ?> <?php echo e(__('lang.ar')); ?></label>
                <input type="text" name="title_Ar" value="<?php echo e($data['title_Ar']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['title_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>

            <h4 class="title"> <?php echo e(__('lang.label')); ?> 1 </h4>
            <div class="mb-3">
                <label for="label1_Fr" class="form-label"><?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?></label>
                <input type="text" name="label1_Fr" value="<?php echo e($data['label1_Fr']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['label1_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="label1_An" class="form-label"><?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?></label>
                <input type="text" name="label1_An" value="<?php echo e($data['label1_An']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['label1_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="label1_Ar" class="form-label"><?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?></label>
                <input type="text" name="label1_Ar" value="<?php echo e($data['label1_Ar']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['label1_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            
            <h4 class="title"> <?php echo e(__('lang.label')); ?> 2 </h4>
            <div class="mb-3">
                <label for="label2_Fr" class="form-label"><?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?></label>
                <input type="text" name="label2_Fr" value="<?php echo e($data['label2_Fr']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['label2_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="label2_An" class="form-label"><?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?></label>
                <input type="text" name="label2_An" value="<?php echo e($data['label2_An']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['label2_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="label2_Ar" class="form-label"><?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?></label>
                <input type="text" name="label2_Ar" value="<?php echo e($data['label2_Ar']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['label2_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>

            <h4 class="title"> <?php echo e(__('lang.label')); ?> 3 </h4>
            <div class="mb-3">
                <label for="label3_Fr" class="form-label"><?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?></label>
                <input type="text" name="label3_Fr" value="<?php echo e($data['label3_Fr']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['label3_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="label3_An" class="form-label"><?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?></label>
                <input type="text" name="label3_An" value="<?php echo e($data['label3_An']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['label3_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="label3_Ar" class="form-label"><?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?></label>
                <input type="text" name="label3_Ar" value="<?php echo e($data['label3_Ar']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['label3_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>

            <h4 class="title"> <?php echo e(__('lang.label')); ?> 4 </h4>
            <div class="mb-3">
                <label for="label4_Fr" class="form-label"><?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?></label>
                <input type="text" name="label4_Fr" value="<?php echo e($data['label4_Fr']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['label4_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="label4_An" class="form-label"><?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?></label>
                <input type="text" name="label4_An" value="<?php echo e($data['label4_An']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['label4_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="label4_Ar" class="form-label"><?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?></label>
                <input type="text" name="label4_Ar" value="<?php echo e($data['label4_Ar']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['label4_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>

            <h4 class="title"> <?php echo e(__('lang.label')); ?> 5 </h4>
            <div class="mb-3">
                <label for="label5_Fr" class="form-label"><?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?></label>
                <input type="text" name="label5_Fr" value="<?php echo e($data['label5_Fr']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['label5_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="label5_An" class="form-label"><?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?></label>
                <input type="text" name="label5_An" value="<?php echo e($data['label5_An']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['label5_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="label5_Ar" class="form-label"><?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?></label>
                <input type="text" name="label5_Ar" value="<?php echo e($data['label5_Ar']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['label5_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>

            <h4 class="title"> <?php echo e(__('lang.button')); ?> </h4>
            <div class="mb-3">
                <label for="button_Fr" class="form-label"><?php echo e(__('lang.button')); ?> <?php echo e(__('lang.fr')); ?></label>
                <input type="text" name="button_Fr" value="<?php echo e($data['button_Fr']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['button_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="button_An" class="form-label"><?php echo e(__('lang.button')); ?> <?php echo e(__('lang.an')); ?></label>
                <input type="text" name="button_An" value="<?php echo e($data['button_An']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['button_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="button_Ar" class="form-label"><?php echo e(__('lang.button')); ?> <?php echo e(__('lang.ar')); ?></label>
                <input type="text" name="button_Ar" value="<?php echo e($data['button_Ar']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['button_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            
            <div class="modal-footer d-flex justify-content-between ">
                <button type="submit" class="btn btn-primary"> <?php echo e(__('lang.edit')); ?> </button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal"> <?php echo e(__('lang.cancel')); ?> </button>
            </div>
        </form>


        </div>
    </div>
          
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syndico1\resources\views/edit/editConnect.blade.php ENDPATH**/ ?>