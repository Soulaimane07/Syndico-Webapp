

<?php $__env->startSection('title', __('lang.modules')); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
          
  <div class="row">
      <div class="col-12">
          <div class="card">
              <div class="card-body">

                  <div class="title">
                      <h4 class="card-title"> <?php echo e(__('lang.modules')); ?> ( <?php echo e($modules->count()); ?> ) </h4>
                      <button type="button" class="create btn btn-primary" data-bs-toggle="modal" data-bs-target="#create"> 
                        <i class="icon-plus"></i> 
                        <?php echo e(__('lang.createmodule')); ?>

                    </button>
                  </div>
                  
                  <?php if($modules->count() > 0): ?> 

                  <div class="table-responsive">
                    
                    <h2 class="table-title"> <?php echo e(__('lang.french')); ?> </h2> 
                    <table id="" class="table table-striped table-bordered display no-wrap"
                      style="width:100%">
                        <thead>
                            <tr>
                              <th>#</th>
                              <th> <?php echo e(__('lang.title')); ?> </th>
                              <th> <?php echo e(__('lang.para')); ?> </th>
                              <th> <?php echo e(__('lang.button')); ?> </th>
                              <th> <?php echo e(__('lang.color')); ?> </th>
                              <th> <?php echo e(__('lang.image')); ?> </th>
                              <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($header['id']); ?></td>
                              <td>
                                <?php if(strlen($header['title_Fr']) > 10): ?>
                                    <?php echo e(Str::limit($header['title_Fr'], 10)); ?>

                                <?php else: ?>
                                    <?php echo e($header['title_Fr']); ?>

                                <?php endif; ?>  
                              </td>
                              <td>
                                <?php if(strlen($header['para_Fr']) > 10): ?>
                                    <?php echo e(Str::limit($header['para_Fr'], 10)); ?>

                                <?php else: ?>
                                    <?php echo e($header['para_Fr']); ?>

                                <?php endif; ?>  
                              </td>
                              <td>
                                <?php if(strlen($header['button_Fr']) > 10): ?>
                                    <?php echo e(Str::limit($header['button_Fr'], 10)); ?>

                                <?php else: ?>
                                    <?php echo e($header['button_Fr']); ?>

                                <?php endif; ?>  
                              </td>
                              <td>
                                <?php if(strlen($header['color']) > 10): ?>
                                    <?php echo e(Str::limit($header['color'], 10)); ?>

                                <?php else: ?>
                                    <?php echo e($header['color']); ?>

                                <?php endif; ?>  
                              </td>
                              <td>
                                <?php if(strlen($header['image']) > 10): ?>
                                    <?php echo e(Str::limit($header['image'], 10)); ?>

                                <?php else: ?>
                                    <?php echo e($header['image']); ?>

                                <?php endif; ?>  
                              </td>
                              <td>
                                <a href=<?php echo e('/edit-module/'.$header['id']); ?>> <button class="edit"> <i class=" icon-pencil"></i> </button> </a>
      
                                <form action="<?php echo e(url('/delete-module/'.$header['id'])); ?>" method="post">
                                    <?php echo e(method_field('DELETE')); ?>

                                    <?php echo e(csrf_field()); ?>

                                    <button id="delete" class='delete'><i class=" icon-trash" ></i></button> 
                                </form> 
                              </td>
                          </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <h2 class="table-title"><?php echo e(__('lang.english')); ?></h2>
                    <table id="" class="table table-striped table-bordered display no-wrap"
                      style="width:100%">
                        <thead>
                            <tr>
                              <th>#</th>
                              <th> <?php echo e(__('lang.title')); ?> </th>
                              <th> <?php echo e(__('lang.para')); ?> </th>
                              <th> <?php echo e(__('lang.button')); ?> </th>
                              <th> <?php echo e(__('lang.color')); ?> </th>
                              <th> <?php echo e(__('lang.image')); ?> </th>
                              <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($header['id']); ?></td>
                              <td>
                                <?php if(strlen($header['title_An']) > 10): ?>
                                    <?php echo e(Str::limit($header['title_An'], 10)); ?>

                                <?php else: ?>
                                    <?php echo e($header['title_An']); ?>

                                <?php endif; ?>  
                              </td>
                              <td>
                                <?php if(strlen($header['para_An']) > 10): ?>
                                    <?php echo e(Str::limit($header['para_An'], 10)); ?>

                                <?php else: ?>
                                    <?php echo e($header['para_An']); ?>

                                <?php endif; ?>  
                              </td>
                              <td>
                                <?php if(strlen($header['button_An']) > 10): ?>
                                    <?php echo e(Str::limit($header['button_An'], 10)); ?>

                                <?php else: ?>
                                    <?php echo e($header['button_An']); ?>

                                <?php endif; ?>  
                              </td>
                              <td>
                                <?php if(strlen($header['color']) > 10): ?>
                                    <?php echo e(Str::limit($header['color'], 10)); ?>

                                <?php else: ?>
                                    <?php echo e($header['color']); ?>

                                <?php endif; ?>  
                              </td>
                              <td>
                                <?php if(strlen($header['image']) > 10): ?>
                                    <?php echo e(Str::limit($header['image'], 10)); ?>

                                <?php else: ?>
                                    <?php echo e($header['image']); ?>

                                <?php endif; ?>  
                              </td>
                              <td>
                                <a href=<?php echo e('/edit-module/'.$header['id']); ?>> <button class="edit"> <i class=" icon-pencil"></i> </button> </a>
      
                                <form action="<?php echo e(url('/delete-module/'.$header['id'])); ?>" method="post">
                                    <?php echo e(method_field('DELETE')); ?>

                                    <?php echo e(csrf_field()); ?>

                                    <button id="delete" class='delete'><i class=" icon-trash" ></i></button> 
                                </form> 
                              </td>
                          </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    
                    <h2 class="table-title"><?php echo e(__('lang.arabic')); ?></h2>
                    <table id="" class="table table-striped table-bordered display no-wrap"
                      style="width:100%">
                        <thead>
                            <tr>
                              <th>#</th>
                              <th> <?php echo e(__('lang.title')); ?> </th>
                              <th> <?php echo e(__('lang.para')); ?> </th>
                              <th> <?php echo e(__('lang.button')); ?> </th>
                              <th> <?php echo e(__('lang.color')); ?> </th>
                              <th> <?php echo e(__('lang.image')); ?> </th>
                              <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($header['id']); ?></td>
                              <td>
                                <?php if(strlen($header['title_Ar']) > 10): ?>
                                    <?php echo e(Str::limit($header['title_Ar'], 10)); ?>

                                <?php else: ?>
                                    <?php echo e($header['title_Ar']); ?>

                                <?php endif; ?>  
                              </td>
                              <td>
                                <?php if(strlen($header['para_Ar']) > 10): ?>
                                    <?php echo e(Str::limit($header['para_Ar'], 10)); ?>

                                <?php else: ?>
                                    <?php echo e($header['para_Ar']); ?>

                                <?php endif; ?>  
                              </td>
                              <td>
                                <?php if(strlen($header['button_Ar']) > 10): ?>
                                    <?php echo e(Str::limit($header['button_Ar'], 10)); ?>

                                <?php else: ?>
                                    <?php echo e($header['button_Ar']); ?>

                                <?php endif; ?>  
                              </td>
                              <td>
                                <?php if(strlen($header['color']) > 10): ?>
                                    <?php echo e(Str::limit($header['color'], 10)); ?>

                                <?php else: ?>
                                    <?php echo e($header['color']); ?>

                                <?php endif; ?>  
                              </td>
                              <td>
                                <?php if(strlen($header['image']) > 10): ?>
                                    <?php echo e(Str::limit($header['image'], 10)); ?>

                                <?php else: ?>
                                    <?php echo e($header['image']); ?>

                                <?php endif; ?>  
                              </td>
                              <td>
                                <a href=<?php echo e('/edit-module/'.$header['id']); ?>> <button class="edit"> <i class=" icon-pencil"></i> </button> </a>
      
                                <form action="<?php echo e(url('/delete-module/'.$header['id'])); ?>" method="post">
                                    <?php echo e(method_field('DELETE')); ?>

                                    <?php echo e(csrf_field()); ?>

                                    <button id="delete" class='delete'><i class=" icon-trash" ></i></button> 
                                </form> 
                              </td>
                          </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                  <?php else: ?>
                    <div class='nodata'>
                      <div class='video'>
                        <video autoplay muted loop src="assets/videos/nodata.mp4"></video>
                      </div>
                        <h2> <?php echo e(__('lang.nodata')); ?> </h2> 
                    </div>
                  <?php endif; ?>

              </div>
          </div>
      </div>
  </div>

  <div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <div class="title">
                  <h4 class="card-title"> <?php echo e(__('lang.extraModules')); ?> </h4>

                  <?php if($modulesextra->count() == 0): ?>
                  <button type="button" class="create btn btn-primary" data-bs-toggle="modal" data-bs-target="#createex"> 
                    <i class="icon-plus"></i> 
                    <?php echo e(__('lang.createitem')); ?>

                  </button>
                  <?php endif; ?>
                </div>
                
                <?php if($modulesextra->count() > 0): ?> 

                <div>
                  <div class="text-white aboutus bg-primary rounded">
                    <div class="row p-2 px-4">
                      <div class="col">
                        Key
                      </div>
                      <div class="col">
                        Value
                      </div>
                    </div>
                  </div>
                  <?php $__currentLoopData = $modulesextra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aboutus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tbody>
                      <h4 class="title text-white bg-secondary rounded p-2 m-3"> <?php echo e(__('lang.title')); ?> </h4>

                      <div class="row p-3 border-bottom">
                        <div class="col">
                          <?php echo e(__('lang.title')); ?> <?php echo e(__('lang.fr')); ?>

                        </div>
                        <div class="col">
                          <?php echo e($aboutus->title_Fr); ?>

                        </div>
                      </div>
                      <div class="row p-3 border-bottom">
                        <div class="col">
                          <?php echo e(__('lang.title')); ?> <?php echo e(__('lang.an')); ?>

                        </div>
                        <div class="col">
                          <?php echo e($aboutus->title_An); ?>

                        </div>
                      </div>
                      <div class="row p-3 border-bottom">
                        <div class="col">
                          <?php echo e(__('lang.title')); ?> <?php echo e(__('lang.ar')); ?>

                        </div>
                        <div class="col">
                          <?php echo e($aboutus->title_Ar); ?>

                        </div>
                      </div>

                      <h4 class="title text-white bg-secondary rounded p-2 m-3"> <?php echo e(__('lang.para')); ?> 1 </h4>
                      
                      <div class="row p-3 border-bottom">
                        <div class="col">
                          <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.fr')); ?>

                        </div>
                        <div class="col">
                          <?php echo e($aboutus->para1_Fr); ?>

                        </div>
                      </div>
                      <div class="row p-3 border-bottom">
                        <div class="col">
                          <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.an')); ?>

                        </div>
                        <div class="col">
                          <?php echo e($aboutus->para1_An); ?>

                        </div>
                      </div>
                      <div class="row p-3 border-bottom">
                        <div class="col">
                           <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.ar')); ?>

                        </div>
                        <div class="col">
                          <?php echo e($aboutus->para1_Ar); ?>

                        </div>
                      </div>

                      <h4 class="title text-white bg-secondary rounded p-2 m-3"> <?php echo e(__('lang.para')); ?> 2 </h4>

                      <div class="row p-3 border-bottom">
                        <div class="col">
                          <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.fr')); ?>

                        </div>
                        <div class="col">
                          <?php echo e($aboutus->para2_Fr); ?>

                        </div>
                      </div>
                      <div class="row p-3 border-bottom">
                        <div class="col">
                          <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.an')); ?>

                        </div>
                        <div class="col">
                          <?php echo e($aboutus->para2_An); ?>

                        </div>
                      </div>
                      <div class="row p-3 border-bottom">
                        <div class="col">
                           <?php echo e(__('lang.para')); ?> <?php echo e(__('lang.ar')); ?>

                        </div>
                        <div class="col">
                          <?php echo e($aboutus->para2_Ar); ?>

                        </div>
                      </div>
                  </tbody>
                  <div class="text-white aboutus ">
                    <div class="row p-2">
                      <div class="col">
                        <a href=<?php echo e('/edit-moduleextra/'.$aboutus['id']); ?>> <button class="edit"> <i class=" icon-pencil"></i> <?php echo e(__('lang.edit')); ?> </button> </a>
                      </div>
                      <div class="col">
                        <form action="<?php echo e(url('/delete-modulesextra/'.$aboutus['id'])); ?>" method="post">
                          <?php echo e(method_field('DELETE')); ?>

                          <?php echo e(csrf_field()); ?>

                          <button id="delete" class='delete'><i class=" icon-trash" ></i> <?php echo e(__('lang.delete')); ?> </button> 
                        </form> 
                      </div>
                    </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </div>

                <?php else: ?>
                
                <div class='nodata'>
                  <div class='video'>
                    <video autoplay muted loop src="assets/videos/nodata.mp4"></video>
                  </div>
                    <h2> <?php echo e(__('lang.nodata')); ?> </h2> 
                </div>
                
                <?php endif; ?>

            </div>
        </div>
    </div>
  </div>

  <div class="modal fade" id="create" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"> <?php echo e(__('lang.createmodule')); ?> </h5>
        </div>
        <div class="modal-body">
            <form method="POST" action="create-module" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <h2><?php echo e(__('lang.french')); ?></h2>

                <div class="mb-3">
                    <label for="name" class="form-label"><?php echo e(__('lang.title')); ?></label>
                    <input type="text" name="title_Fr" value="<?php echo e(old('title_Fr')); ?>" class="form-control" id="name" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['title_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label"> <?php echo e(__('lang.para')); ?> </label>
                    <input type="text" name="para_Fr" value="<?php echo e(old('para_Fr')); ?>" class="form-control" id="para_Fr" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['para_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                  <div class="mb-3">
                    <label for="imm" class="form-label"> <?php echo e(__('lang.button')); ?> </label>
                    <input type="text" name="button_Fr" value="<?php echo e(old('button_Fr')); ?>" class="form-control" id="number" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['button_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                  
                <h2><?php echo e(__('lang.english')); ?></h2>

                <div class="mb-3">
                    <label for="name" class="form-label"><?php echo e(__('lang.title')); ?></label>
                    <input type="text" name="title_An" value="<?php echo e(old('title_An')); ?>" class="form-control" id="name" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['title_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label"> <?php echo e(__('lang.para')); ?> </label>
                    <input type="text" name="para_An" value="<?php echo e(old('para_An')); ?>" class="form-control" id="para_An" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['para_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                  <div class="mb-3">
                    <label for="imm" class="form-label"> <?php echo e(__('lang.button')); ?> </label>
                    <input type="text" name="button_An" value="<?php echo e(old('button_An')); ?>" class="form-control" id="number" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['button_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                
                <h2><?php echo e(__('lang.arabic')); ?></h2>

                <div class="mb-3">
                    <label for="name" class="form-label"><?php echo e(__('lang.title')); ?></label>
                    <input type="text" name="title_Ar" value="<?php echo e(old('title_Ar')); ?>" class="form-control" id="name" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['title_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label"> <?php echo e(__('lang.para')); ?> </label>
                    <input type="text" name="para_Ar" value="<?php echo e(old('para_Ar')); ?>" class="form-control" id="para_Ar" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['para_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                  <div class="mb-3">
                    <label for="imm" class="form-label"> <?php echo e(__('lang.button')); ?> </label>
                    <input type="text" name="button_Ar" value="<?php echo e(old('button_Ar')); ?>" class="form-control" id="number" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['button_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>

                <hr>

                <div class="mb-3">
                  <label for="color" class="form-label"> <?php echo e(__('lang.color')); ?> </label>
                  <input type="text" name="color" value="<?php echo e(old('color')); ?>" class="form-control" id="number" aria-describedby="emailHelp">
                  <span class="text-danger"> <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>

                <div class="form-group mb-3">
                  <label for="" class="form-label">  <?php echo e(__('lang.image')); ?>  </label>
                  <input type="file" value="<?php echo e(old('image')); ?>" name="image" class="form-control" >
                  <span class="text-danger"> <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                


                <div class="modal-footer d-flex justify-content-between ">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('lang.create')); ?></button>
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('lang.cancel')); ?></button>
                </div>
              </form>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="createex" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"> <?php echo e(__('lang.extraModules')); ?> </h5>
        </div>
        <div class="modal-body">
            <form method="POST" action="create-modulesextra">
                <?php echo csrf_field(); ?>

                <h2><?php echo e(__('lang.french')); ?></h2>

                <div class="mb-3">
                    <label for="name" class="form-label"><?php echo e(__('lang.title')); ?></label>
                    <input type="text" name="title_Fr" value="<?php echo e(old('title_Fr')); ?>" class="form-control" id="name" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['title_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label"> <?php echo e(__('lang.para')); ?> 1 </label>
                    <input type="text" name="para1_Fr" value="<?php echo e(old('para1_Fr')); ?>" class="form-control" id="para1_Fr" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['para1_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                  <label for="phone" class="form-label"> <?php echo e(__('lang.para')); ?> 2 </label>
                  <input type="text" name="para2_Fr" value="<?php echo e(old('para2_Fr')); ?>" class="form-control" id="para2_Fr" aria-describedby="emailHelp">
                  <span class="text-danger"> <?php $__errorArgs = ['para2_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
              </div>
                
                  
                <h2><?php echo e(__('lang.english')); ?></h2>

                <div class="mb-3">
                    <label for="name" class="form-label"><?php echo e(__('lang.title')); ?></label>
                    <input type="text" name="title_An" value="<?php echo e(old('title_An')); ?>" class="form-control" id="name" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['title_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                  <label for="phone" class="form-label"> <?php echo e(__('lang.para')); ?> 1 </label>
                  <input type="text" name="para1_An" value="<?php echo e(old('para1_An')); ?>" class="form-control" id="para1_An" aria-describedby="emailHelp">
                  <span class="text-danger"> <?php $__errorArgs = ['para1_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
              </div>
              <div class="mb-3">
                <label for="phone" class="form-label"> <?php echo e(__('lang.para')); ?> 2 </label>
                <input type="text" name="para2_An" value="<?php echo e(old('para2_An')); ?>" class="form-control" id="para2_An" aria-describedby="emailHelp">
                <span class="text-danger"> <?php $__errorArgs = ['para2_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
                
                <h2><?php echo e(__('lang.arabic')); ?></h2>

                <div class="mb-3">
                    <label for="name" class="form-label"><?php echo e(__('lang.title')); ?></label>
                    <input type="text" name="title_Ar" value="<?php echo e(old('title_Ar')); ?>" class="form-control" id="name" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['title_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                  <label for="phone" class="form-label"> <?php echo e(__('lang.para')); ?> 1  </label>
                  <input type="text" name="para1_Ar" value="<?php echo e(old('para1_Ar')); ?>" class="form-control" id="para1_Ar" aria-describedby="emailHelp">
                  <span class="text-danger"> <?php $__errorArgs = ['para1_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
              </div>
              <div class="mb-3">
                <label for="phone" class="form-label"> <?php echo e(__('lang.para')); ?> 2 </label>
                <input type="text" name="para2_Ar" value="<?php echo e(old('para2_Ar')); ?>" class="form-control" id="para2_Ar" aria-describedby="emailHelp">
                <span class="text-danger"> <?php $__errorArgs = ['para2_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>

                <div class="modal-footer d-flex justify-content-between ">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('lang.create')); ?></button>
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('lang.cancel')); ?></button>
                </div>
              </form>
        </div>
      </div>
    </div>
  </div>
  
</div>          

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syndico1\resources\views/topics/modules.blade.php ENDPATH**/ ?>