

<?php $__env->startSection('title', __('lang.contacts') ); ?>

<?php $__env->startSection('content'); ?>

  <div class="container-fluid">
          
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <div class="title">
                        <h4 class="card-title"> <?php echo e(__('lang.contacts')); ?> ( <?php echo e($contacts->count()); ?> )</h4>
                    </div>
                    
                    <?php if($contacts->count() > 0): ?> 

                    <div class="table-responsive">
                        <table id="zero_config" class="table table-striped table-bordered display no-wrap"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th><?php echo e(__('lang.fname')); ?></th>
                                    <th><?php echo e(__('lang.lname')); ?></th>
                                    <th><?php echo e(__('lang.email')); ?></th>
                                    <th><?php echo e(__('lang.phone')); ?></th>
                                    <th><?php echo e(__('lang.message')); ?></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($contact['id']); ?></td>
                                    <td><?php echo e($contact['first_name']); ?></td>
                                    <td><?php echo e($contact['last_name']); ?></td>
                                    <td><?php echo e($contact['email']); ?></td>
                                    <td><?php echo e($contact['phone']); ?></td>
                                    <td>
                                        <?php if(strlen($contact['message']) > 25): ?>
                                            <?php echo e(Str::limit($contact['message'], 25)); ?>

                                        <?php else: ?>
                                            <?php echo e($contact['message']); ?>

                                        <?php endif; ?>  
                                    </td>
                                    <td>

                                        <?php if(Auth::user()->is_admin == 1 ): ?>

                                        <a href=<?php echo e('/edit-contact/'.$contact['id']); ?>> <button class="edit"> <i class=" icon-pencil"></i> </button> </a>
        
                                        <form action="<?php echo e(url('/delete-contact/'.$contact['id'])); ?>" method="post">
                                            <?php echo e(method_field('DELETE')); ?>

                                            <?php echo e(csrf_field()); ?>

                                            <button id="delete" class='delete'><i class=" icon-trash" ></i></button> 
                                        </form> 

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <?php else: ?>
                    
                    <div class='nodata'>
                      <div class='video'>
                        <video autoplay muted loop src="assets/videos/nodata.mp4"></video>
                      </div>
                        <h2> <?php echo e(__('lang.nodata')); ?> </h2> 
                    </div>
                    
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
    
  </div>          

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syndico1\resources\views/contacts.blade.php ENDPATH**/ ?>