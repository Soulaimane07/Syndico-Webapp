

<?php $__env->startSection('title', __('lang.profile') ); ?>

<?php $__env->startSection('content'); ?>

    <div class="card mb-3" style="max-width: 100%;">
        <div class="row g-0">
        <div class="profile col-md-4">
            <img src="
                <?php if(Auth::user()->image): ?>
                    <?php echo e(asset('uploads/users/'.Auth::user()->image)); ?>

                <?php else: ?>
                    <?php echo e(asset('uploads/users/default.jpg')); ?>

                <?php endif; ?>
            " alt="">
        </div>
        <div class="col-md-8">
            <div class="card-body">
            <h2 class="card-title"><?php echo e(Auth::user()->name); ?></h2>
            <h5 class="card-title"><?php echo e(Auth::user()->email); ?></h5>
            <h5 class="card-title">
                <?php if(Auth::user()->is_admin == 1 ): ?>
                    <span class="text-success"> <?php echo e(__('lang.admin')); ?> </span>
                <?php else: ?>
                    <span class="text-danger"> <?php echo e(__('lang.user')); ?> </span>
                <?php endif; ?>
            </h5>
            <br>

            <div class="">
                <a href="locale/fr"> <?php echo e(__('lang.french')); ?> </a> |
                <a href="locale/en"><?php echo e(__('lang.english')); ?></a> |
                <a href="locale/ar"><?php echo e(__('lang.arabic')); ?></a>
            </div>

            <div class="d-flex mt-4">
                <button class="delete bg-primary"> 
                    <a 
                        class="sidebar-link sidebar-link"
                        href="<?php echo e(route('logout')); ?>" 
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"
                    >
                        <i data-feather="log-out" class="text-white feather-icon"></i>
                        <span class="text-white"> <?php echo e(__('lang.logout')); ?> </span>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </button>

                <a href=<?php echo e('/edit-user/'.Auth::user()->id); ?>> <button class="mx-4 edit"> <i class=" icon-pencil"></i> <?php echo e(__('lang.edit')); ?> </button> </a>

                <form action="<?php echo e(url('/delete-profile/'. Auth::user()->id )); ?>" method="post">
                    <?php echo e(method_field('DELETE')); ?>

                    <?php echo e(csrf_field()); ?>

                    <button id="delete" class='delete'><i class=" icon-trash"></i> <?php echo e(__('lang.delete')); ?> </button> 
                </form> 
            </div>
        </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syndico1\resources\views/profile.blade.php ENDPATH**/ ?>