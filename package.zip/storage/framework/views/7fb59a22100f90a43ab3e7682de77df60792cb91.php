

<?php $__env->startSection('title', __('lang.editdeuser') .' '.$data['id']); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <h2 class="page-title text-truncate text-dark font-weight-medium mb-1"> <?php echo e(__('lang.editdeuser')); ?> <?php echo e($data['id']); ?>  </h2>
        <form method="POST" action="<?php echo e(url('/edit-user/'.$data['id'])); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="full_name" class="form-label"><?php echo e(__('lang.name')); ?></label>
                <input id="name" type="text" name="name" value="<?php echo e($data['name']); ?>" placeholder="Enter Full Name" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label"><?php echo e(__('lang.email')); ?></label>
                <input type="email" name="email" value="<?php echo e($data['email']); ?>" placeholder="Enter email" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="stat" class="form-label"><?php echo e(__('lang.stat')); ?></label>
                <select name="stat" value="<?php echo e($data['stat']); ?>" aria-label="Default select example" class="form-control">
                    <option value="1"><?php echo e(__('lang.admin')); ?></option>
                    <option value="0"><?php echo e(__('lang.user')); ?></option>
                </select>
            </div>

            <div class="form-group mb-3">
                <label for="" class="form-label"> Image </label>
                <input type="file" value="<?php echo e($data['image']); ?>" name="image" class="form-control" >
            </div>

            <div class="mb-3">
                <label for="password" class="form-label"> <?php echo e(__('lang.pass')); ?> </label>
                <input id="password" value="<?php echo e($data['password']); ?>" type="text" class="form-control "name="password" required autocomplete="new-password">
                <span class="text-danger"> <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="city" class="form-label"> <?php echo e(__('lang.conpass')); ?></label>
                <input id="password-confirm"  value="<?php echo e($data['password']); ?>" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
            </div>
            
            <div class="modal-footer d-flex justify-content-between ">
                <button type="submit" class="btn btn-primary"><?php echo e(__('lang.edit')); ?></button>
                <a href="/users" type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('lang.cancel')); ?></a>
            </div>
        </form>


    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syndico1\resources\views/edit/editUser.blade.php ENDPATH**/ ?>