

<?php $__env->startSection('title', __('lang.editdemande') .' ' .$data['id']); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <h2 class="page-title text-truncate text-dark font-weight-medium mb-1"> <?php echo e(__('lang.editdemande')); ?> <?php echo e($data['id']); ?>  </h2>
        <form method="POST" action="<?php echo e(url('/edit-demande/'.$data['id'])); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="full_name" class="form-label"><?php echo e(__('lang.name')); ?></label>
                <input type="text" name="full_name" value="<?php echo e($data['full_name']); ?>" placeholder="Enter Full Name" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label"><?php echo e(__('lang.email')); ?></label>
                <input type="email" name="email" value="<?php echo e($data['email']); ?>" placeholder="Enter email" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label"><?php echo e(__('lang.phone')); ?></label>
                <input type="number" name="phone" value="<?php echo e($data['phone']); ?>" placeholder="Phone number" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="city" class="form-label"><?php echo e(__('lang.city')); ?></label>
                <input type="text" name="city" value="<?php echo e($data['city']); ?>" placeholder="the City" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="n_imm" class="form-label"><?php echo e(__('lang.imm')); ?></label>
                <input type="number" name="n_imm" value="<?php echo e($data['n_imm']); ?>" placeholder="Number of Immeuble" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['n_imm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="n_app" class="form-label"><?php echo e(__('lang.app')); ?></label>
                <input type="number" name="n_app" value="<?php echo e($data['n_app']); ?>" placeholder="Number of Appartements" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['n_app'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="modal-footer d-flex justify-content-between ">
                <button type="submit" class="btn btn-primary"><?php echo e(__('lang.edit')); ?></button>
                <a href="/demandes" type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('lang.cancel')); ?></a>
            </div>
        </form>


        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syndico1\resources\views/edit/editDemande.blade.php ENDPATH**/ ?>