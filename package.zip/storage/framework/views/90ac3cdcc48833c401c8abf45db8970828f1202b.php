

<?php $__env->startSection('title', __('lang.users') ); ?>

<?php $__env->startSection('content'); ?>

  <div class="container-fluid">
  
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <div class="title">
                        <h4 class="card-title"> <?php echo e(__('lang.users')); ?> ( <?php echo e($users->count()); ?> )</h4>
                        
                        <?php if(Auth::user()->is_admin == 1 ): ?>
                            
                        <button type="button" class="create btn btn-primary" data-bs-toggle="modal" data-bs-target="#create"> 
                          <i class="icon-plus"></i> 
                          <?php echo e(__('lang.createuser')); ?>

                        </button>
                        
                        <?php endif; ?>

                    </div>
                    
                    <div class="table-responsive">
                        <table id="zero_config" class="table table-striped table-bordered display no-wrap"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th><?php echo e(__('lang.name')); ?></th>
                                    <th><?php echo e(__('lang.email')); ?></th>
                                    <th><?php echo e(__('lang.stat')); ?></th>
                                    <th><?php echo e(__('lang.pass')); ?></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user['id']); ?></td>
                                    <td><?php echo e($user['name']); ?></td>
                                    <td><?php echo e($user['email']); ?></td>
                                    <td>
                                      <?php if($user['is_admin'] == 1 ): ?>
                                        <span class="bg-success text-white"> <?php echo e(__('lang.admin')); ?> </span>
                                      <?php else: ?>
                                        <span class="bg-danger text-white"> <?php echo e(__('lang.user')); ?> </span>
                                      <?php endif; ?>
                                    </td>
                                    <td>
                                      <?php if(strlen($user['password']) > 25): ?>
                                        <?php echo e(Str::limit($user['password'], 25)); ?>

                                      <?php else: ?>
                                        <?php echo e($user['password']); ?>

                                      <?php endif; ?>  
                                    </td>
                                    <td>
                                      <?php if(Auth::user()->is_admin == 1): ?>

                                        <a href=<?php echo e('/edit-user/'.$user['id']); ?>> <button class="edit"> <i class=" icon-pencil"></i> </button> </a>
        
                                        <form action="<?php echo e(url('/delete-user/'.$user['id'])); ?>" method="post">
                                            <?php echo e(method_field('DELETE')); ?>

                                            <?php echo e(csrf_field()); ?>

                                            <button id="delete" class='delete'><i class=" icon-trash" ></i></button> 
                                        </form> 
                                      
                                      <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
  </div>
  
  <div class="modal" id="create">
    <div class="modal-dialog">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title"><?php echo e(__('lang.createuser')); ?></h4>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <form method="POST" action="/create-user">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
              <label for="full_name" class="form-label"><?php echo e(__('lang.name')); ?></label>
              <input id="name" type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="Enter Full Name" class="form-control">
              <span class="text-danger"> <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
              <label for="email" class="form-label"><?php echo e(__('lang.email')); ?></label>
              <input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Enter email" class="form-control">
              <span class="text-danger"> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>


            <div class="mb-3">
              <label for="stat" class="form-label"><?php echo e(__('lang.stat')); ?></label>
              <select name="stat" class="form-control" aria-label="Default select example">
                <option value="1"><?php echo e(__('lang.admin')); ?></option>
                <option value="0"><?php echo e(__('lang.user')); ?></option>
              </select>
            </div>
            

            <div class="mb-3">
              <label for="password" class="form-label"> <?php echo e(__('lang.pass')); ?> </label>
              <input id="password" type="password" class="form-control "name="password" required autocomplete="new-password">
              <span class="text-danger"> <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
              <label for="city" class="form-label"> <?php echo e(__('lang.conpass')); ?></label>
              <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
            </div>
            
            <div class="modal-footer d-flex justify-content-between ">
              <button type="submit" class="btn btn-primary"><?php echo e(__('lang.create')); ?></button>
              <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('lang.cancel')); ?></button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syndico1\resources\views/users.blade.php ENDPATH**/ ?>