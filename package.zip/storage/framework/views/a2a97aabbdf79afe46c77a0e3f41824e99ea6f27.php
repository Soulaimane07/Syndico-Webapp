

<?php $__env->startSection('title', __('lang.editextraModules')); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <h2 class="page-title text-truncate text-dark font-weight-medium mb-1"> <?php echo e(__('lang.editextraModules')); ?></h2>
        <form method="POST" action="<?php echo e(url('/edit-moduleextra/'.$data['id'])); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <h2 class="title"><?php echo e(__('lang.french')); ?></h2>
            <div>
                <div class="mb-3">
                    <label for="title_Fr" class="form-label"><?php echo e(__('lang.title')); ?></label>
                    <input type="text" name="title_Fr" value="<?php echo e($data['title_Fr']); ?>" class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['title_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="para_Fr" class="form-label"><?php echo e(__('lang.para')); ?> 1</label>
                    <input type="text" name="para1_Fr" value="<?php echo e($data['para1_Fr']); ?>" class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['para1_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="para_Fr" class="form-label"><?php echo e(__('lang.para')); ?> 2</label>
                    <input type="text" name="para2_Fr" value="<?php echo e($data['para2_Fr']); ?>" class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['para2_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
            </div>

            <hr>
            <h2 class="title"><?php echo e(__('lang.english')); ?></h2>
            <div>
                <div class="mb-3">
                    <label for="title_An" class="form-label"><?php echo e(__('lang.title')); ?></label>
                    <input type="text" name="title_An" value="<?php echo e($data['title_An']); ?>" class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['title_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="para_An" class="form-label"><?php echo e(__('lang.para')); ?> 1 </label>
                    <input type="text" name="para1_An" value="<?php echo e($data['para1_An']); ?>" class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['para1_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="para_An" class="form-label"><?php echo e(__('lang.para')); ?> 2 </label>
                    <input type="text" name="para2_An" value="<?php echo e($data['para2_An']); ?>" class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['para2_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
            </div>

            <hr>
            <h2 class="title"><?php echo e(__('lang.arabic')); ?></h2>
            <div>
                <div class="mb-3">
                    <label for="title_Ar" class="form-label"><?php echo e(__('lang.title')); ?></label>
                    <input type="text" name="title_Ar" value="<?php echo e($data['title_Ar']); ?>" class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['title_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="para_Ar" class="form-label"><?php echo e(__('lang.para')); ?> 1</label>
                    <input type="text" name="para1_Ar" value="<?php echo e($data['para1_Ar']); ?>" class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['para1_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="para_Ar" class="form-label"><?php echo e(__('lang.para')); ?> 2</label>
                    <input type="text" name="para2_Ar" value="<?php echo e($data['para2_Ar']); ?>" class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['para2_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
            </div>
            
            <div class="modal-footer d-flex justify-content-between ">
                <button type="submit" class="btn btn-primary"><?php echo e(__('lang.edit')); ?></button>
                <a href="/modules" type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('lang.cancel')); ?></a>
            </div>
        </form>


        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syndico1\resources\views/edit/editModuleextra.blade.php ENDPATH**/ ?>