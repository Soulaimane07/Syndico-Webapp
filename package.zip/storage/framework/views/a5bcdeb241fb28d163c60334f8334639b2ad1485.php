

<?php $__env->startSection('title', __('lang.header') ); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
          
  <div class="row">
      <div class="col-12">
          <div class="card">
              <div class="card-body">

                  <div class="title">
                      <h4 class="card-title"> <?php echo e(__('lang.headeritems')); ?>  ( <?php echo e($header->count()); ?> )</h4>
                      <button type="button" class="create btn btn-primary" data-bs-toggle="modal" data-bs-target="#create"> 
                        <i class="icon-plus"></i> 
                        <?php echo e(__('lang.createitem')); ?>

                    </button>
                  </div>
                  
                  <?php if($header->count() > 0): ?> 

                  <div class="table-responsive">
                    
                      <h2 class="table-title"><?php echo e((__('lang.french'))); ?></h2> 
                      <table id="" class="table table-striped table-bordered display no-wrap"
                        style="width:100%">
                          <thead>
                              <tr>
                                <th>#</th>
                                <th><?php echo e(__('lang.title')); ?> 1</th>
                                <th><?php echo e(__('lang.title')); ?> 2</th>
                                <th> <?php echo e(__('lang.para')); ?> </th>
                                <th><?php echo e(__('lang.image')); ?></th>
                                <th> <?php echo e(__('lang.button')); ?> </th>
                                <th></th>
                              </tr>
                          </thead>
                          <tbody>
                              <?php $__currentLoopData = $header; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($header['id']); ?></td>
                                <td>
                                  <?php if(strlen($header['title1_Fr']) > 10): ?>
                                      <?php echo e(Str::limit($header['title1_Fr'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($header['title1_Fr']); ?>

                                  <?php endif; ?>  
                                </td>
                                <td>
                              
                                  <?php if(strlen($header['title2_Fr']) > 10): ?>
                                      <?php echo e(Str::limit($header['title2_Fr'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($header['title2_Fr']); ?>

                                  <?php endif; ?>  
                                  
                                  </td>
                                <td>
                                  <?php if(strlen($header['para_Fr']) > 10): ?>
                                      <?php echo e(Str::limit($header['para_Fr'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($header['para_Fr']); ?>

                                  <?php endif; ?>  </td>
                                <td>
                                  <?php if(strlen($header['image']) > 10): ?>
                                      <?php echo e(Str::limit($header['image'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($header['image']); ?>

                                  <?php endif; ?>  
                                </td>
                                <td>
                              
                                  <?php if(strlen($header['button_Fr']) > 10): ?>
                                      <?php echo e(Str::limit($header['button_Fr'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($header['button_Fr']); ?>

                                  <?php endif; ?>  
                              </td>
                                <td>
                                  <a href=<?php echo e('/edit-header/'.$header['id']); ?>> <button class="edit"> <i class=" icon-pencil"></i> </button> </a>
        
                                  <form action="<?php echo e(url('/delete-header-item/'.$header['id'])); ?>" method="post">
                                      <?php echo e(method_field('DELETE')); ?>

                                      <?php echo e(csrf_field()); ?>

                                      <button id="delete" class='delete'><i class=" icon-trash" ></i></button> 
                                  </form> 
                                </td>
                            </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                      </table>

                      <h2 class="table-title"> <?php echo e(__('lang.english')); ?> </h2>
                      <table id="" class="table table-striped table-bordered display no-wrap"
                          style="width:100%">
                          <thead>
                              <tr>
                                <th>#</th>
                                <th><?php echo e(__('lang.title')); ?> 1</th>
                                <th><?php echo e(__('lang.title')); ?> 2</th>
                                <th> <?php echo e(__('lang.para')); ?> </th>
                                <th><?php echo e(__('lang.image')); ?></th>
                                <th> <?php echo e(__('lang.button')); ?> </th>
                                <th></th>
                              </tr>
                          </thead>
                          <tbody>
                              <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($header['id']); ?></td>
                                <td>
                                  <?php if(strlen($header['title1_An']) > 10): ?>
                                      <?php echo e(Str::limit($header['title1_An'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($header['title1_An']); ?>

                                  <?php endif; ?>  
                                </td>
                                <td>
                              
                                  <?php if(strlen($header['title2_An']) > 10): ?>
                                      <?php echo e(Str::limit($header['title2_An'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($header['title2_An']); ?>

                                  <?php endif; ?>  
                                  
                                  </td>
                                <td>
                                  <?php if(strlen($header['para_An']) > 10): ?>
                                      <?php echo e(Str::limit($header['para_An'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($header['para_An']); ?>

                                  <?php endif; ?>  </td>
                                <td>
                                  <?php if(strlen($header['image']) > 10): ?>
                                      <?php echo e(Str::limit($header['image'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($header['image']); ?>

                                  <?php endif; ?>  
                                </td>
                                <td>
                              
                                  <?php if(strlen($header['button_An']) > 10): ?>
                                      <?php echo e(Str::limit($header['button_An'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($header['button_An']); ?>

                                  <?php endif; ?>  
                              </td>
                                <td>
                                  <a href=<?php echo e('/edit-header/'.$header['id']); ?>> <button class="edit"> <i class=" icon-pencil"></i> </button> </a>
        
                                  <form action="<?php echo e(url('/delete-header-item/'.$header['id'])); ?>" method="post">
                                      <?php echo e(method_field('DELETE')); ?>

                                      <?php echo e(csrf_field()); ?>

                                      <button id="delete" class='delete'><i class=" icon-trash" ></i></button> 
                                  </form> 
                                </td>
                            </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                      </table>

                      <h2 class="table-title"><?php echo e(__('lang.arabic')); ?></h2>
                      <table id="" class="table table-striped table-bordered display no-wrap"
                          style="width:100%">
                          <thead>
                              <tr>
                                <th>#</th>
                                <th><?php echo e(__('lang.title')); ?> 1</th>
                                <th><?php echo e(__('lang.title')); ?> 2</th>
                                <th> <?php echo e(__('lang.para')); ?> </th>
                                <th><?php echo e(__('lang.image')); ?></th>
                                <th> <?php echo e(__('lang.button')); ?> </th>
                                <th></th>
                              </tr>
                          </thead>
                          <tbody>
                              <?php $__currentLoopData = $headerss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($header['id']); ?></td>
                                <td>
                                  <?php if(strlen($header['title1_Ar']) > 10): ?>
                                      <?php echo e(Str::limit($header['title1_Ar'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($header['title1_Ar']); ?>

                                  <?php endif; ?>  
                                </td>
                                <td>
                              
                                  <?php if(strlen($header['title2_Ar']) > 10): ?>
                                      <?php echo e(Str::limit($header['title2_Ar'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($header['title2_Ar']); ?>

                                  <?php endif; ?>  
                                  
                                  </td>
                                <td>
                                  <?php if(strlen($header['para_Ar']) > 10): ?>
                                      <?php echo e(Str::limit($header['para_Ar'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($header['para_Ar']); ?>

                                  <?php endif; ?>  </td>
                                <td>
                                  <?php if(strlen($header['image']) > 10): ?>
                                      <?php echo e(Str::limit($header['image'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($header['image']); ?>

                                  <?php endif; ?>  
                                </td>
                                <td>
                              
                                  <?php if(strlen($header['button_Ar']) > 10): ?>
                                      <?php echo e(Str::limit($header['button_Ar'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($header['button_Ar']); ?>

                                  <?php endif; ?>  
                              </td>
                                <td>
                                  <a href=<?php echo e('/edit-header/'.$header['id']); ?>> <button class="edit"> <i class=" icon-pencil"></i> </button> </a>
        
                                  <form action="<?php echo e(url('/delete-header-item/'.$header['id'])); ?>" method="post">
                                      <?php echo e(method_field('DELETE')); ?>

                                      <?php echo e(csrf_field()); ?>

                                      <button id="delete" class='delete'><i class=" icon-trash" ></i></button> 
                                  </form> 
                                </td>
                            </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                      </table>
                      
                  </div>

                  <?php else: ?>
                  
                  <div class='nodata'>
                    <div class='video'>
                      <video autoplay muted loop src="assets/videos/nodata.mp4"></video>
                    </div>
                      <h2> <?php echo e(__('lang.nodata')); ?> </h2> 
                  </div>
                  
                  <?php endif; ?>

              </div>
          </div>
      </div>
  </div>

  <div class="modal fade" id="create" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"> <?php echo e(__('lang.createheaderitem')); ?> </h5>
        </div>
        <div class="modal-body">
            <form method="POST" action="create-header-bloc" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <h2><?php echo e(__('lang.french')); ?></h2>

                <div class="mb-3">
                    <label for="name" class="form-label"><?php echo e(__('lang.title')); ?> 1</label>
                    <input type="text" name="title1_Fr" value="<?php echo e(old('title1_Fr')); ?>" class="form-control" id="name" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['title1_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                  <label for="exampleInputEmail1" class="form-label"><?php echo e(__('lang.title')); ?> 2</label>
                  <input type="text" name="title2_Fr" value="<?php echo e(old('title2_Fr')); ?>" class="form-control" id="title2_Fr" aria-describedby="emailHelp">
                  <span class="text-danger"> <?php $__errorArgs = ['title2_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label"> <?php echo e(__('lang.para')); ?> </label>
                    <input type="text" name="para_Fr" value="<?php echo e(old('para_Fr')); ?>" class="form-control" id="para_Fr" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['para_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                  <div class="mb-3">
                    <label for="imm" class="form-label"> <?php echo e(__('lang.button')); ?> </label>
                    <input type="text" name="button_Fr" value="<?php echo e(old('button_Fr')); ?>" class="form-control" id="number" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['button_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                  
                <h2><?php echo e(__('lang.english')); ?></h2>

                <div class="mb-3">
                    <label for="name" class="form-label"><?php echo e(__('lang.title')); ?> 1</label>
                    <input type="text" name="title1_An" value="<?php echo e(old('title1_An')); ?>" class="form-control" id="name" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['title1_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                  <label for="exampleInputEmail1" class="form-label"><?php echo e(__('lang.title')); ?> 2</label>
                  <input type="text" name="title2_An" value="<?php echo e(old('title2_An')); ?>" class="form-control" id="title2_An" aria-describedby="emailHelp">
                  <span class="text-danger"> <?php $__errorArgs = ['title2_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label"> <?php echo e(__('lang.para')); ?> </label>
                    <input type="text" name="para_An" value="<?php echo e(old('para_An')); ?>" class="form-control" id="para_An" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['para_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                  <div class="mb-3">
                    <label for="imm" class="form-label"> <?php echo e(__('lang.button')); ?> </label>
                    <input type="text" name="button_An" value="<?php echo e(old('button_An')); ?>" class="form-control" id="number" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['button_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                
                <h2><?php echo e(__('lang.arabic')); ?></h2>

                <div class="mb-3">
                    <label for="name" class="form-label"><?php echo e(__('lang.title')); ?> 1</label>
                    <input type="text" name="title1_Ar" value="<?php echo e(old('title1_Ar')); ?>" class="form-control" id="name" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['title1_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                  <label for="exampleInputEmail1" class="form-label"><?php echo e(__('lang.title')); ?> 2</label>
                  <input type="text" name="title2_Ar" value="<?php echo e(old('title2_Ar')); ?>" class="form-control" id="title2_Ar" aria-describedby="emailHelp">
                  <span class="text-danger"> <?php $__errorArgs = ['title2_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label"> <?php echo e(__('lang.para')); ?> </label>
                    <input type="text" name="para_Ar" value="<?php echo e(old('para_Ar')); ?>" class="form-control" id="para_Ar" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['para_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                  <div class="mb-3">
                    <label for="imm" class="form-label"> <?php echo e(__('lang.button')); ?> </label>
                    <input type="text" name="button_Ar" value="<?php echo e(old('button_Ar')); ?>" class="form-control" id="number" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['button_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>

                <hr>

                <div class="form-group mb-3">
                  <label for="" class="form-label"> Image </label>
                  <input type="file" value="<?php echo e(old('image')); ?>" name="image" class="form-control" >
                  <span class="text-danger"> <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                


                <div class="modal-footer d-flex justify-content-between ">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('lang.create')); ?></button>
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('lang.cancel')); ?></button>
                </div>
              </form>
        </div>
      </div>
    </div>
  </div>
  
</div>          

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syndico1\resources\views/topics/header.blade.php ENDPATH**/ ?>