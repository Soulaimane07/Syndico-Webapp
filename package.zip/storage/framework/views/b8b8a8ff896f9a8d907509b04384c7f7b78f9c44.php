

<?php $__env->startSection('title', __('lang.editcontact') .' '.$data['id']); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <h2 class="page-title text-truncate text-dark font-weight-medium mb-1"> <?php echo e(__('lang.editcontact')); ?> <?php echo e($data['id']); ?>  </h2>
        <form method="POST" action="<?php echo e(url('/edit-contact/'.$data['id'])); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="first_name" class="form-label"><?php echo e(__('lang.fname')); ?></label>
                <input type="text" name="first_name" value="<?php echo e($data['first_name']); ?>" placeholder="Enter First Name" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="last_name" class="form-label"><?php echo e(__('lang.lname')); ?></label>
                <input type="text" name="last_name" value="<?php echo e($data['last_name']); ?>" placeholder="Enter Last Name" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label"><?php echo e(__('lang.email')); ?></label>
                <input type="email" name="email" value="<?php echo e($data['email']); ?>" placeholder="Enter email" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label"><?php echo e(__('lang.phone')); ?></label>
                <input type="number" name="phone" value="<?php echo e($data['phone']); ?>" placeholder="Phone number" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($phone); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="mb-3">
                <label for="message" class="form-label"><?php echo e(__('lang.message')); ?></label>
                <input type="text" name="message" value="<?php echo e($data['message']); ?>" placeholder="the Message" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="modal-footer d-flex justify-content-between ">
                <button type="submit" class="btn btn-primary"><?php echo e(__('lang.edit')); ?></button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('lang.cancel')); ?></button>
            </div>
        </form>


        </div>
    </div>
          
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syndico1\resources\views/edit/editcontact.blade.php ENDPATH**/ ?>