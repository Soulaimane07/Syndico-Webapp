

<?php $__env->startSection('title', __('lang.editmodule') .' '.$data['id']); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <h2 class="page-title text-truncate text-dark font-weight-medium mb-1"> <?php echo e(__('lang.editmodule')); ?> <?php echo e($data['id']); ?>  </h2>
        <form method="POST" action="<?php echo e(url('/edit-module/'.$data['id'])); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <h2 class="title"><?php echo e(__('lang.french')); ?></h2>
            <div>
                <div class="mb-3">
                    <label for="title_Fr" class="form-label"><?php echo e(__('lang.title')); ?></label>
                    <input type="text" name="title_Fr" value="<?php echo e($data['title_Fr']); ?>" class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['title_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="para_Fr" class="form-label"><?php echo e(__('lang.para')); ?></label>
                    <input type="text" name="para_Fr" value="<?php echo e($data['para_Fr']); ?>" class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['para_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="button_Fr" class="form-label"><?php echo e(__('lang.button')); ?></label>
                    <input type="text" name="button_Fr" value="<?php echo e($data['button_Fr']); ?>"  class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['button_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
            </div>

            <hr>
            <h2 class="title"><?php echo e(__('lang.english')); ?></h2>
            <div>
                <div class="mb-3">
                    <label for="title_An" class="form-label"><?php echo e(__('lang.title')); ?></label>
                    <input type="text" name="title_An" value="<?php echo e($data['title_An']); ?>" class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['title_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="para_An" class="form-label"><?php echo e(__('lang.para')); ?></label>
                    <input type="text" name="para_An" value="<?php echo e($data['para_An']); ?>" class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['para_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="button_An" class="form-label"><?php echo e(__('lang.button')); ?></label>
                    <input type="text" name="button_An" value="<?php echo e($data['button_An']); ?>"  class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['button_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
            </div>

            <hr>
            <h2 class="title"><?php echo e(__('lang.arabic')); ?></h2>
            <div>
                <div class="mb-3">
                    <label for="title_Ar" class="form-label"><?php echo e(__('lang.title')); ?></label>
                    <input type="text" name="title_Ar" value="<?php echo e($data['title_Ar']); ?>" class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['title_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="para_Ar" class="form-label"><?php echo e(__('lang.para')); ?></label>
                    <input type="text" name="para_Ar" value="<?php echo e($data['para_Ar']); ?>" class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['para_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
                <div class="mb-3">
                    <label for="button_Ar" class="form-label"><?php echo e(__('lang.button')); ?></label>
                    <input type="text" name="button_Ar" value="<?php echo e($data['button_Ar']); ?>"  class="form-control">
                    <span class="text-danger"> <?php $__errorArgs = ['button_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                </div>
            </div>
            
            <hr>
            <div class="mb-3">
                <label for="color" class="form-label"><?php echo e(__('lang.color')); ?></label>
                <input type="text" name="color" value="<?php echo e($data['color']); ?>" class="form-control">
                <span class="text-danger"> <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="form-group mb-3">
                <label for="" class="form-label">  <?php echo e(__('lang.image')); ?>  </label>
                <input type="file" value="<?php echo e($data['image']); ?>" name="image" class="form-control" >
                <span class="text-danger"> <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
            <div class="modal-footer d-flex justify-content-between ">
                <button type="submit" class="btn btn-primary"><?php echo e(__('lang.edit')); ?></button>
                <a href="/modules" type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('lang.cancel')); ?></a>
            </div>
        </form>


        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syndico1\resources\views/edit/editmodule.blade.php ENDPATH**/ ?>