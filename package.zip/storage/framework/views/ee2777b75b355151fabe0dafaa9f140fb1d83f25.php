

<?php $__env->startSection('title', __('lang.navbar') ); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
          
    <div class="row">
      <div class="col-12">
          <div class="card">
              <div class="card-body">

                  <div class="title">
                      <h4 class="card-title"> <?php echo e(__('lang.navitems')); ?> ( <?php echo e($navbar->count()); ?> )</h4>
                      
                      <?php if($navbar->count() < 6): ?>
                      <button type="button" class="create btn btn-primary" data-bs-toggle="modal" data-bs-target="#create"> 
                        <i class="icon-plus"></i> 
                        <?php echo e(__('lang.createitem')); ?>

                      </button>
                      <?php endif; ?>
                  </div>
                  
                  <?php if($navbar->count() > 0): ?> 

                  <div class="table-responsive">
                      <table id="zero_config" class="table table-striped table-bordered display no-wrap"
                          style="width:100%">
                          <thead>
                              <tr>
                                <th>#</th>
                                <th><?php echo e(__('lang.title')); ?> <?php echo e(__('lang.fr')); ?> </th>
                                <th><?php echo e(__('lang.title')); ?> <?php echo e(__('lang.an')); ?></th>
                                <th><?php echo e(__('lang.title')); ?> <?php echo e(__('lang.ar')); ?></th>
                                <th><?php echo e(__('lang.image')); ?></th>
                                <th><?php echo e(__('lang.logo')); ?></th>
                                <th><?php echo e(__('lang.link')); ?></th>
                                <th></th>
                              </tr>
                          </thead>
                          <tbody>
                              <?php $__currentLoopData = $navbar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navbar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($navbar['id']); ?></td>
                                <td>
                                  <?php if(strlen($navbar['title_Fr']) > 10): ?>
                                      <?php echo e(Str::limit($navbar['title_Fr'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($navbar['title_Fr']); ?>

                                  <?php endif; ?>  
                                  
                                  </td>
                                <td>
                              
                                  <?php if(strlen($navbar['title_An']) > 10): ?>
                                      <?php echo e(Str::limit($navbar['title_An'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($navbar['title_An']); ?>

                                  <?php endif; ?>  
                                  
                                  </td>
                                <td>
                                  <?php if(strlen($navbar['title_Ar']) > 10): ?>
                                      <?php echo e(Str::limit($navbar['title_Ar'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($navbar['title_Ar']); ?>

                                  <?php endif; ?>  </td>
                                <td>
                                  <?php if(strlen($navbar['image']) > 10): ?>
                                      <?php echo e(Str::limit($navbar['image'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($navbar['image']); ?>

                                  <?php endif; ?>  
                                </td>
                                <td>
                              
                                  <?php if(strlen($navbar['logo']) > 10): ?>
                                      <?php echo e(Str::limit($navbar['logo'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($navbar['logo']); ?>

                                  <?php endif; ?>  
                              </td>
                                <td>
                                  <?php if(strlen($navbar['link']) > 10): ?>
                                      <?php echo e(Str::limit($navbar['link'], 10)); ?>

                                  <?php else: ?>
                                      <?php echo e($navbar['link']); ?>

                                  <?php endif; ?> 
                              </td>
                                <td>
                                  <a href=<?php echo e('/edit-navbar/'.$navbar['id']); ?>> <button class="edit"> <i class=" icon-pencil"></i> </button> </a>
        
                                  <form action="<?php echo e(url('/delete-navbar-item/'.$navbar['id'])); ?>" method="post">
                                      <?php echo e(method_field('DELETE')); ?>

                                      <?php echo e(csrf_field()); ?>

                                      <button id="delete" class='delete'><i class=" icon-trash" ></i></button> 
                                  </form> 
                                </td>
                            </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                      </table>
                  </div>

                  <?php else: ?>
                  
                  <div class='nodata'>
                    <div class='video'>
                      <video autoplay muted loop src="assets/videos/nodata.mp4"></video>
                    </div>
                      <h2> <?php echo e(__('lang.nodata')); ?> </h2> 
                  </div>
                  
                  <?php endif; ?>

              </div>
          </div>
      </div>

    </div>
    
    <div class="modal fade" id="create" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('lang.createitem')); ?></h5>
          </div>
          <div class="modal-body">
              <form method="POST" action="create-navbar-item" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <div class="mb-3">
                      <label for="name" class="form-label"><?php echo e(__('lang.title')); ?> <?php echo e(__('lang.fr')); ?></label>
                      <input type="text" name="title_Fr" value="<?php echo e(old('title_Fr')); ?>" class="form-control" id="name" aria-describedby="emailHelp">
                      <span class="text-danger"> <?php $__errorArgs = ['title_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label"><?php echo e(__('lang.title')); ?> <?php echo e(__('lang.an')); ?></label>
                    <input type="text" name="title_An" value="<?php echo e(old('title_An')); ?>" class="form-control" id="title_An" aria-describedby="emailHelp">
                    <span class="text-danger"> <?php $__errorArgs = ['title_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                      <label for="phone" class="form-label"> <?php echo e(__('lang.title')); ?> <?php echo e(__('lang.ar')); ?> </label>
                      <input type="text" name="title_Ar" value="<?php echo e(old('title_Ar')); ?>" class="form-control" id="title_Ar" aria-describedby="emailHelp">
                      <span class="text-danger"> <?php $__errorArgs = ['title_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="form-group mb-3">
                    <label for="" class="form-label"> Image </label>
                    <input type="file" value="<?php echo e(old('image')); ?>" name="image" class="form-control" >
                    <span class="text-danger"> <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                    <div class="mb-3">
                      <label for="imm" class="form-label"> <?php echo e(__('lang.logo')); ?> </label>
                      <input type="text" name="logo" value="<?php echo e(old('logo')); ?>" class="form-control" id="number" aria-describedby="emailHelp">
                      <span class="text-danger"> <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                    <div class="mb-3">
                      <label for="app" class="form-label"><?php echo e(__('lang.link')); ?></label>
                      <input type="text" name="link" value="<?php echo e(old('link')); ?>" class="form-control" id="app" aria-describedby="emailHelp">
                      <span class="text-danger"> <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  
                  <div class="modal-footer d-flex justify-content-between ">
                      <button type="submit" class="btn btn-primary"><?php echo e(__('lang.create')); ?></button>
                      <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('lang.cancel')); ?></button>
                  </div>
                </form>
          </div>
        </div>
      </div>
    </div>
    
</div>          

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syndico1\resources\views/topics/navbar.blade.php ENDPATH**/ ?>