

<?php $__env->startSection('title', __('lang.demandez') ); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
  
                    <div class="title">
                      <h4 class="card-title"> <?php echo e(__('lang.demandez')); ?> </h4>
  
                      <?php if($demandes->count() == 0): ?>
                      <button type="button" class="create btn btn-primary" data-bs-toggle="modal" data-bs-target="#create"> 
                        <i class="icon-plus"></i> 
                        <?php echo e(__('lang.createitem')); ?>

                      </button>
                      <?php endif; ?>
                    </div>
                    
                    <?php if($demandes->count() > 0): ?> 
  
                    <div>
                      <div class="text-white aboutus bg-primary rounded">
                        <div class="row p-2 px-4">
                          <div class="col">
                            Key
                          </div>
                          <div class="col">
                            Value
                          </div>
                        </div>
                      </div>
                      
                      <?php $__currentLoopData = $demandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $demande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tbody>
  
                          <h4 class="title text-white bg-secondary rounded p-2 m-3"> <?php echo e(__('lang.title')); ?> </h4>
  
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.title')); ?> <?php echo e(__('lang.fr')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->title_Fr); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.title')); ?> <?php echo e(__('lang.an')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->title_An); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.title')); ?> <?php echo e(__('lang.ar')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->title_Ar); ?>

                            </div>
                          </div>
  
                          <h4 class="title text-white bg-secondary rounded p-2 m-3"> <?php echo e(__('lang.label')); ?> 1 </h4>
                          
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label1_Fr); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label1_An); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                               <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label1_Ar); ?>

                            </div>
                          </div>
  
                          <h4 class="title text-white bg-secondary rounded p-2 m-3"> <?php echo e(__('lang.label')); ?> 2 </h4>
  
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label2_Fr); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label2_An); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                               <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label2_Ar); ?>

                            </div>
                          </div>
  
                          <h4 class="title text-white bg-secondary rounded p-2 m-3"> <?php echo e(__('lang.label')); ?> 3 </h4>
  
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label3_Fr); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label3_An); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                               <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label3_Ar); ?>

                            </div>
                          </div>
  
                          <h4 class="title text-white bg-secondary rounded p-2 m-3"> <?php echo e(__('lang.label')); ?> 4 </h4>
  
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label4_Fr); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label4_An); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                               <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label4_Ar); ?>

                            </div>
                          </div>
  
                          <h4 class="title text-white bg-secondary rounded p-2 m-3"> <?php echo e(__('lang.label')); ?> 5 </h4>
  
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label5_Fr); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label5_An); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label5_Ar); ?>

                            </div>
                          </div>

                          <h4 class="title text-white bg-secondary rounded p-2 m-3"> <?php echo e(__('lang.label')); ?> 6 </h4>

                          <div class="row p-3 border-bottom">
                            <div class="col">
                               <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label6_Fr); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label6_An); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                               <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->label6_Ar); ?>

                            </div>
                          </div>
  
                          <h4 class="title text-white bg-secondary rounded p-2 m-3"> <?php echo e(__('lang.button')); ?> 1 </h4>
  
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.button')); ?> <?php echo e(__('lang.fr')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->button1_Fr); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.button')); ?> <?php echo e(__('lang.an')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->button1_An); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                               <?php echo e(__('lang.button')); ?> <?php echo e(__('lang.ar')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->button1_Ar); ?>

                            </div>
                          </div>

                          <h4 class="title text-white bg-secondary rounded p-2 m-3"> <?php echo e(__('lang.button')); ?> 2 </h4>
  
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.button')); ?> <?php echo e(__('lang.fr')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->button2_Fr); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                              <?php echo e(__('lang.button')); ?> <?php echo e(__('lang.an')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->button2_An); ?>

                            </div>
                          </div>
                          <div class="row p-3 border-bottom">
                            <div class="col">
                               <?php echo e(__('lang.button')); ?> <?php echo e(__('lang.ar')); ?>

                            </div>
                            <div class="col">
                              <?php echo e($demande->button2_Ar); ?>

                            </div>
                          </div>
  
                      </tbody>
                      <div class="text-white demande ">
                        <div class="row p-2">
                          <div class="col">
                            <a href=<?php echo e('/edit-demandez/'.$demande['id']); ?>> <button class="edit"> <i class=" icon-pencil"></i> <?php echo e(__('lang.edit')); ?> </button> </a>
                          </div>
                          <div class="col">
                            <form action="<?php echo e(url('/delete-demandez/'.$demande['id'])); ?>" method="post">
                              <?php echo e(method_field('DELETE')); ?>

                              <?php echo e(csrf_field()); ?>

                              <button id="delete" class='delete'><i class=" icon-trash" ></i> <?php echo e(__('lang.delete')); ?> </button> 
                            </form> 
                          </div>
                        </div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                    </div>
  
                    <?php else: ?>
                    
                    <div class='nodata'>
                      <div class='video'>
                        <video autoplay muted loop src="assets/videos/nodata.mp4"></video>
                      </div>
                        <h2> <?php echo e(__('lang.nodata')); ?> </h2> 
                    </div>
                    
                    <?php endif; ?>
  
                </div>
            </div>
        </div>
    </div>
  
    <div class="modal fade" id="create" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"> <?php echo e(__('lang.createitem')); ?></h5>
          </div>
          <div class="modal-body">
              <form method="POST" action="create-demandez">
                  <?php echo csrf_field(); ?>
  
                  <h4 class="title"> <?php echo e(__('lang.title')); ?> </h4>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.title')); ?> <?php echo e(__('lang.fr')); ?></label>
                    <input type="text" name="title_Fr" value="<?php echo e(old('title_Fr')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['title_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.title')); ?> <?php echo e(__('lang.an')); ?></label>
                    <input type="text" name="title_An" value="<?php echo e(old('title_An')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['title_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.title')); ?> <?php echo e(__('lang.ar')); ?></label>
                    <input type="text" name="title_Ar" value="<?php echo e(old('title_Ar')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['title_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  
                  <h4 class="title"> <?php echo e(__('lang.label')); ?> 1</h4>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?></label>
                    <input type="text" name="label1_Fr" value="<?php echo e(old('label1_Fr')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label1_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?></label>
                    <input type="text" name="label1_An" value="<?php echo e(old('label1_An')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label1_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?></label>
                    <input type="text" name="label1_Ar" value="<?php echo e(old('label1_Ar')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label1_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
  
                  <h4 class="title"> <?php echo e(__('lang.label')); ?> 2</h4>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?></label>
                    <input type="text" name="label2_Fr" value="<?php echo e(old('label2_Fr')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label2_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?></label>
                    <input type="text" name="label2_An" value="<?php echo e(old('label2_An')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label2_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?></label>
                    <input type="text" name="label2_Ar" value="<?php echo e(old('label2_Ar')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label2_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
  
                  <h4 class="title"> <?php echo e(__('lang.label')); ?> 3</h4>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?></label>
                    <input type="text" name="label3_Fr" value="<?php echo e(old('label3_Fr')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label3_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?></label>
                    <input type="text" name="label3_An" value="<?php echo e(old('label3_An')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label3_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?></label>
                    <input type="text" name="label3_Ar" value="<?php echo e(old('label3_Ar')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label3_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
  
                  <h4 class="title"> <?php echo e(__('lang.label')); ?> 4</h4>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?></label>
                    <input type="text" name="label4_Fr" value="<?php echo e(old('label4_Fr')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label4_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?></label>
                    <input type="text" name="label4_An" value="<?php echo e(old('label4_An')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label4_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?></label>
                    <input type="text" name="label4_Ar" value="<?php echo e(old('label4_Ar')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label4_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
  
                  <h4 class="title"> <?php echo e(__('lang.label')); ?> 5</h4>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?></label>
                    <input type="text" name="label5_Fr" value="<?php echo e(old('label5_Fr')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label5_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?></label>
                    <input type="text" name="label5_An" value="<?php echo e(old('label5_An')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label5_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?></label>
                    <input type="text" name="label5_Ar" value="<?php echo e(old('label5_Ar')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label5_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>

                  <h4 class="title"> <?php echo e(__('lang.label')); ?> 6</h4>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.fr')); ?></label>
                    <input type="text" name="label6_Fr" value="<?php echo e(old('label6_Fr')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label6_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.an')); ?></label>
                    <input type="text" name="label6_An" value="<?php echo e(old('label6_An')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label6_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.label')); ?> <?php echo e(__('lang.ar')); ?></label>
                    <input type="text" name="label6_Ar" value="<?php echo e(old('label6_Ar')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['label6_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
  
                  <h4 class="title"> <?php echo e(__('lang.button')); ?> 1</h4>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.button')); ?> <?php echo e(__('lang.fr')); ?></label>
                    <input type="text" name="button1_Fr" value="<?php echo e(old('button1_Fr')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['button1_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.button')); ?> <?php echo e(__('lang.an')); ?></label>
                    <input type="text" name="button1_An" value="<?php echo e(old('button1_An')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['button1_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.button')); ?> <?php echo e(__('lang.ar')); ?></label>
                    <input type="text" name="button1_Ar" value="<?php echo e(old('button1_Ar')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['button1_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>

                  <h4 class="title"> <?php echo e(__('lang.button')); ?> 2</h4>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.button')); ?> <?php echo e(__('lang.fr')); ?></label>
                    <input type="text" name="button2_Fr" value="<?php echo e(old('button2_Fr')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['button2_Fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.button')); ?> <?php echo e(__('lang.an')); ?></label>
                    <input type="text" name="button2_An" value="<?php echo e(old('button2_An')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['button2_An'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  <div class="mb-3">
                    <label for="name" class="form-label"> <?php echo e(__('lang.button')); ?> <?php echo e(__('lang.ar')); ?></label>
                    <input type="text" name="button2_Ar" value="<?php echo e(old('button2_Ar')); ?>" class="form-control" id="name" >
                    <span class="text-danger"> <?php $__errorArgs = ['button2_Ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                  </div>
                  
                  
                  <div class="modal-footer d-flex justify-content-between ">
                      <button type="submit" class="btn btn-primary"> <?php echo e(__('lang.create')); ?> </button>
                      <button type="button" class="btn btn-danger" data-bs-dismiss="modal"> <?php echo e(__('lang.cancel')); ?> </button>
                  </div>
                </form>
          </div>
        </div>
      </div>
    </div>

</div>          

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syndico1\resources\views/topics/demandez.blade.php ENDPATH**/ ?>